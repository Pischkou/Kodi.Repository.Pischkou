# -*- coding: utf-8 -*-

#########################################################################
 #  --| NEST ADDON |--
 #########################################################################
 # ----------------------------------------------------------------------
 #  This program is free software: you can redistribute it and/or modify
 #  it under the terms of the GNU General Public License as published by
 #  the Free Software Foundation, either version 3 of the License, or
 #  (at your option) any later version.

 #  This program is distributed in the hope that it will be useful,
 #  but WITHOUT ANY WARRANTY; without even the implied warranty of
 #  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #  GNU General Public License for more details.

 #  You should have received a copy of the GNU General Public License
 #  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 # ----------------------------------------------------------------------
#########################################################################

import re, requests, base64, urllib, urlparse

from resources.lib.modules import common
from resources.lib.modules import log_utils

class source:
    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = ['primewire.io']
        self.base_link = 'http://www.primewire.io'
        self.movie_search_link = '%s/search/%s'
        self.tv_search_link = '%s/searchtv/%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            movie_id  = common.clean_search(title.lower().replace(' ','%20'))

            headers={'User-Agent':common.random_agent()}

            start_url = self.movie_search_link % (self.base_link, movie_id)

            headers = {'User_Agent':common.random_agent()}
            OPEN = requests.get(start_url,headers=headers,timeout=5).content
            content = re.compile('<p><b><a href="(.+?)".+?FONTSIZE.+?>(.+?)<font color="#8B4513">(.+?)</font>',re.DOTALL).findall(OPEN)
            for show_url,item_title,date in content:

                if not common.clean_title(title).lower() == common.clean_title(item_title).lower():
                    continue
                if not year in date:
                    continue
                
                movie_link = show_url

            return movie_link
        except Exception as e:
            log_utils.log('[PRIMEIO-MOVIE] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except Exception as e:
            log_utils.log('[PRIMEIO-TVSHOW] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return
            urldata = urlparse.parse_qs(url)
            urldata = dict((i, urldata[i][0]) for i in urldata)
            title = urldata['tvshowtitle'].replace(':', ' ').lower()

            show_id  = common.clean_search(title.lower().replace(' ','%20'))

            headers={'User-Agent':common.random_agent()}

            start_url = self.tv_search_link % (self.base_link, show_id)

            headers = {'User_Agent':common.random_agent()}
            OPEN = requests.get(start_url,headers=headers,timeout=5).content
            content = re.compile('<div class="item".+?href="(.+?)"',re.DOTALL).findall(OPEN)
            for show_url in content:

                if common.clean_title(title).lower() in common.clean_title(show_url).lower():
                        headers = {'User_Agent':common.random_agent()}
                        episodes = requests.get(show_url,headers=headers,timeout=5).content

                        eps = re.compile('class="tv_episode_item".+?href="(.+?)"',re.DOTALL).findall(episodes)
                        for episode_url in eps:
                            ep_chk = '-season-%s-episode-%s.html' %(season,episode)
                            if not episode_url.endswith(ep_chk):
                                continue
                            tvshow_link = episode_url
                
            return tvshow_link
        except Exception as e:
            log_utils.log('[PRIMEIO-EPISODE] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url == None: return
        try:
            headers = {'User_Agent':common.random_agent()}
            content = requests.get(url,headers=headers,timeout=3).content 

            links = re.compile('data-height="460">(.+?)<',re.DOTALL).findall(content)
            count = 0
            for host_url in links:
                if self.base_link in host_url:
                    host = re.compile('movie=(.+?)&',re.DOTALL).findall(host_url)[0]
                    final_url = base64.b64decode(host)
                else:
                    final_url = host_url
                host = final_url.split('//')[1].replace('www.','')
                host = host.split('/')[0].lower()
                host = host.split('.')[0].title()
                count +=1
                if '1080' in final_url:
                    qual = '1080p'
                elif '720' in final_url:
                    qual='720p'
                else:
                    qual='SD'
                sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': final_url, 'direct': False, 'debridonly': False})

            return sources
        except Exception as e:
            log_utils.log('[PRIMEIO-SOURCE] Error: %s' % (e), log_utils.LOGDEBUG)
            return sources

    def resolve(self, url):
        return url
