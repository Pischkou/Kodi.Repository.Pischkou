import re, requests, base64, urllib, urlparse

from resources.lib.modules import common
from resources.lib.modules import log_utils

# clean_title,clean_search,random_agent,filter_host

class source:
    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = ['yesmovies.to']
        self.base_link = 'https://yesmovies.to'
        self.search_link = '/search/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'type': 'movie', 'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except Exception as e:
            log_utils.log('[DAREWATCH-MOVIE] Error: %s' % (e), log_utils.LOGNOTICE)
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except Exception as e:
            log_utils.log('[DAREWATCH-TVSHOW] Error: %s' % (e), log_utils.LOGNOTICE)
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return
            urldata = urlparse.parse_qs(url)
            urldata = dict((i, urldata[i][0]) for i in urldata)
            title = urldata['tvshowtitle'].replace(':', ' ').lower()
            year = urldata['year'].lower()
            url = {'type': 'tv-show', 'imdb': imdb, 'tvdb': tvdb, 'title': title, 'year': year, 'premiered': premiered, 'season': season, 'episode': episode}
            url = urllib.urlencode(url)

            return url
        except Exception as e:
            log_utils.log('[DAREWATCH-EPISODE] Error: %s' % (e), log_utils.LOGNOTICE)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url == None: return
        urldata = urlparse.parse_qs(url)
        urldata = dict((i, urldata[i][0]) for i in urldata)
        tipo = urldata['type']
        try:
            if(tipo == "movie"):
                title = urldata['title']
                year = urldata['year']
                # MOVIE
                try:
                    start_url = self.base_link + self.search_link + title.replace(' ','+')+'.html'
                    title = title
                    m_list = self._check_for_movie(title, start_url)
                except:
                    start_url2 = self.base_link + self.search_link + title.replace(' ','+')+'+'+year+'.html'
                    title = title+year
                    m_list = self._check_for_movie(title, start_url2)
                for item in m_list:
                    m = item[0]; match=item[1]; qual=item[2]
                    url = 'https://yesmovies.to/ajax/movie_token?eid='+m+'&mid='+match
                    html3 = requests.get(url).content
                    x,y = re.findall("_x='(.+?)', _y='(.+?)'",html3)[0]
                    fin_url = 'https://yesmovies.to/ajax/movie_sources/'+m+'?x='+x+'&y='+y
                    h = requests.get(fin_url).content
                    playlink = re.findall('"file":"(.+?)"(.+?)}',h)
                    count = 0
                    for p,rest in playlink:
                        try:
                            qual = re.findall('"label":"(.+?)"',str(rest))[0]
                        except:
                            qual = item[2]
                        p = p.replace('\\','')
                        if 'srt' in p or 'spanish' in qual or 'googleapis' in p:
                            pass
                        else:
                            if 'english' in qual:
                                qual = '720p'
                            if 'lemon' in p:
                                p = p+'|User-Agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0&Host=streaming.lemonstream.me:1443&Referer=https://yesmovies.to'
                            if 'http' in p:
                                count +=1
                                if "1080p" not in qual or "720p" not in qual:
                                    qual = "SD"
                                sources.append({'source': 'DirectLink', 'quality': qual, 'language': 'en', 'url': p, 'direct': True, 'debridonly': False})
            else:
                title = urldata['title']
                year = urldata['year']
                season = urldata['season']
                premiered = urldata['premiered']
                episode = urldata['episode']
                #TV SHOW
                start_url = self.base_link + self.search_link+title.replace(' ','+') + '.html'
                html = requests.get(start_url).content
                match = re.compile('<div class="ml-item">.+?<a href="(.+?)".+?title="(.+?)"',re.DOTALL).findall(html)
                for url,name in match:
                    if common.clean_title(title)+'season'+season == common.clean_title(name):
                        html2 = requests.get(url).content
                        match2 = re.findall('favorite\((.+?),',html2)[0]
                        get_ep = requests.get('https://yesmovies.to/ajax/v4_movie_episodes/'+match2).content
                        block = re.compile('data-id="(.+?)".+?title="(.+?)">').findall(get_ep.replace('\\',''))
                        for ID,name in block:
                            if 'Episode' in name:
                                ep = re.findall('Episode (.+?):',str(name))[0]
                                if len(episode) == 1:
                                    episode = '0'+episode
                                if episode == ep:
                                    m = ID
                                    match = match2
                                    qual = 'SD'
                                    url = 'https://yesmovies.to/ajax/movie_token?eid='+m+'&mid='+match
                                    html3 = requests.get(url).content
                                    x,y = re.findall("_x='(.+?)', _y='(.+?)'",html3)[0]
                                    fin_url = 'https://yesmovies.to/ajax/movie_sources/'+m+'?x='+x+'&y='+y
                                    h = requests.get(fin_url).content
                                    playlink = re.findall('"file":"(.+?)"(.+?)}',h)
                                    count = 0
                                    for p,rest in playlink:
                                        try:
                                            qual = re.findall('"label":"(.+?)"',str(rest))[0]
                                        except:
                                            qual = "SD"
                                        p = p.replace('\\','')
                                        if 'srt' in p or 'spanish' in qual or 'googleapis' in p:
                                            pass
                                        else:
                                            if 'english' in qual:
                                                qual = '720p'
                                            if 'lemon' in p:
                                                p = p+'|User-Agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0&Host=streaming.lemonstream.me:1443&Referer=https://yesmovies.to'
                                            if 'http' in p:
                                                count +=1
                                                if "1080p" not in qual or "720p" not in qual:
                                                    qual = "SD"
                                                sources.append({'source': 'DirectLink', 'quality': qual, 'language': 'en', 'url': p, 'direct': True, 'debridonly': False})

            return sources
        except Exception as e:
            log_utils.log('[DAREWATCH-SOURCE] Error: %s' % (e), log_utils.LOGNOTICE)
            return sources

    def resolve(self, url):
        return url

    def _check_for_movie(self, title, start_url):
        try:
            m_list = []
            html = requests.get(start_url).content
            match = re.compile('<div class="ml-item">.+?<a href="(.+?)".+?title="(.+?)"',re.DOTALL).findall(html)
            for url,name in match:
                if common.clean_search(title.replace(' ','')) == common.clean_search(name).replace(' ',''):
                    html = requests.get(url).content
                    match = re.findall('favorite\((.+?),',html)[0]
                    second_url = 'https://yesmovies.to/ajax/v4_movie_episodes/' + match
                    html2 = requests.get(second_url).content
                    match2 = re.compile('<li class=.+?data-id=.+?"(.+?)".+?title=.+?"(.+?)"').findall(html2)
                    for m,qual in match2:
                        m = m.replace('\\','')
                        qual = qual.replace('\\','').replace('HD-','')
                        if len(m)==6 or len(m)==7:
                            m_list.append((m,match,qual))
                    return m_list
        except Exception as e:
            log_utils.log('[DAREWATCH-CHECK] Error: %s' % (e), log_utils.LOGNOTICE)
            return []
