# -*- coding: utf-8 -*-

#########################################################################
 #  --| NEST ADDON |--
 #########################################################################
 # ----------------------------------------------------------------------
 #  This program is free software: you can redistribute it and/or modify
 #  it under the terms of the GNU General Public License as published by
 #  the Free Software Foundation, either version 3 of the License, or
 #  (at your option) any later version.

 #  This program is distributed in the hope that it will be useful,
 #  but WITHOUT ANY WARRANTY; without even the implied warranty of
 #  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #  GNU General Public License for more details.

 #  You should have received a copy of the GNU General Public License
 #  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 # ----------------------------------------------------------------------
#########################################################################

import re, requests, base64, urllib, urlparse

from resources.lib.modules import common
from resources.lib.modules import log_utils

class source:
    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = ['mydarewatch.com']
        self.base_link = 'http://www.mydarewatch.com'
        self.search_link = self.base_link + '/index.php'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            search_id = common.clean_search(title.lower())
            
            #print 'darewatch ID> ' + search_id
            headers = {'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                       'accept-encoding':'gzip, deflate, br','accept-language':'en-US,en;q=0.8','content-type':'application/x-www-form-urlencoded',
                       'User-Agent':common.random_agent(),'origin':self.base_link,'referer':self.base_link+'/search'}
            
            data = {'menu': 'search','query': search_id}
            
            html = requests.post(self.search_link,headers=headers,data=data,timeout=5).content
            page = html.split('Movie results for:')[1]
            Regex = re.compile('<h4>.+?class="link" href="(.+?)" title="(.+?)"',re.DOTALL).findall(page)
            for item_url,name in Regex:
                #print '(grabbed url) %s  (title) %s' %(item_url,name)
                if not common.clean_title(title).lower() == common.clean_title(name).lower():
                    continue
                if not year in name:
                    continue

                movie_link = item_url

            return movie_link
        except Exception as e:
            log_utils.log('[DAREWATCH-MOVIE] Error: %s' % (e), log_utils.LOGNOTICE)
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except Exception as e:
            log_utils.log('[DAREWATCH-TVSHOW] Error: %s' % (e), log_utils.LOGNOTICE)
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return
            urldata = urlparse.parse_qs(url)
            urldata = dict((i, urldata[i][0]) for i in urldata)
            title = urldata['tvshowtitle'].replace(':', ' ').lower()

            search_id = common.clean_search(title.lower())

            headers = {'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                       'accept-encoding':'gzip, deflate, br','accept-language':'en-US,en;q=0.8','content-type':'application/x-www-form-urlencoded',
                       'User-Agent':common.random_agent(),'origin':self.base_link,'referer':self.base_link+'/search'}
            
            data = {'menu': 'search','query': search_id}
            
            html = requests.post(self.search_link,headers=headers,data=data,timeout=5).content
            page = html.split('TV show results for:')[1]
            Regex = re.compile('<h4>.+?class="link" href="(.+?)" title="(.+?)"',re.DOTALL).findall(page)
            for item_url,name in Regex:
                if not common.clean_title(title).lower() == common.clean_title(name).lower():
                    continue
                if '/watchm/' not in item_url:
                    item_url = item_url + '/season/%s/episode/%s' %(season, episode)
                    tvshow_link = item_url
                
            return tvshow_link
        except Exception as e:
            log_utils.log('[DAREWATCH-EPISODE] Error: %s' % (e), log_utils.LOGNOTICE)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url == None: return
        try:
            headers = {'User-Agent':common.random_agent()}

            html = requests.get(url,headers=headers,timeout=10).content

            match = re.compile("] = '(.+?)'",re.DOTALL).findall(html)
            count = 0
            for vid in match:
                host = base64.b64decode(vid)
                link=re.compile('.+?="(.+?)"',re.DOTALL).findall(host)[0]
                if 'openload' in link:
                    try:
                        get_res=requests.get(link,headers=headers,timeout=5).content
                        rez = re.compile('description" content="(.+?)"',re.DOTALL).findall(get_res)[0]
                        if '1080' in rez:
                            qual = '1080p'
                        elif '720' in rez:
                            qual='720p'
                        else:
                            qual='SD'
                    except:qual='SD'
                    count +=1
                    sources.append({'source': 'Openload', 'quality': qual, 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})
                else: 
                    hoster = link.split('//')[1].replace('www.','')
                    hoster = hoster.split('/')[0].lower()
                    count +=1
                    sources.append({'source': hoster, 'quality': 'SD', 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})

            return sources
        except Exception as e:
            log_utils.log('[DAREWATCH-SOURCE] Error: %s' % (e), log_utils.LOGNOTICE)
            return sources

    def resolve(self, url):
        return url