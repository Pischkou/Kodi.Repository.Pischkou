import re, urlparse, urllib, base64, requests

from resources.lib.modules import log_utils
from resources.lib.modules import cfscrape

class source:
    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = ['openloadmovie.me']
        self.base_link = 'https://openloadmovie.me'
        self.search_link = '%s/?s=%s'
        self.scraper = cfscrape.create_scraper()

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            search_id = self._clean_search(title.lower())
            start_url = self.search_link % (self.base_link, search_id.replace(' ','+'))
            headers = {'User_Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'}
            #html = requests.get(start_url,headers=headers,timeout=5).content
            html = self.scraper.get(start_url,headers=headers,timeout=5).content
            log_utils.log('[OPENLOADMOVIE-HTML] %s' % (html), log_utils.LOGNOTICE)
            Regex = re.compile('class="result-item".+?href="(.+?)".+?alt="(.+?)"',re.DOTALL).findall(html)
            for item_url,name in Regex:
                if not self._clean_title(title).lower() == self._clean_title(name).lower():
                    continue
                if not year in name:
                    continue
                movie_link = item_url
            
            return movie_link
        except Exception as e:
            log_utils.log('[OPENLOADMOVIE-MOVIE] Error: %s' % (e), log_utils.LOGNOTICE)
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except Exception as e:
            log_utils.log('[OPENLOADMOVIE-TVSHOW] Error: %s' % (e), log_utils.LOGNOTICE)
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['premiered'], url['season'], url['episode'] = premiered, season, episode
            
            try:
                search_id = self._clean_search(title.lower())
                start_url = self.search_link % (self.base_link,search_id.replace(' ','+'))
                headers = {'User_Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'}
                #html = requests.get(start_url,headers=headers,timeout=5).content
                html = self.scraper.get(start_url,headers=headers,timeout=5).content
                Regex = re.compile('class="result-item".+?href="(.+?)".+?alt="(.+?)"',re.DOTALL).findall(html)
                for item_url,name in Regex:
                    if not self._clean_title(title).lower() == self._clean_title(name).lower():
                        continue
                    if "/tvshows/" in item_url:
                        movie_link = item_url[:-5].replace('/tvshows/','/episodes/')+'%sx%s/'%(season,episode)
                
                return movie_link
            except Exception as e:
                log_utils.log('[OPENLOADMOVIE-EPISODE] Error: %s' % (e), log_utils.LOGNOTICE)
                return
        except Exception as e:
            log_utils.log('[OPENLOADMOVIE-EPISODE] Error: %s' % (e), log_utils.LOGNOTICE)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url == None: return
        try:
            html = self.scraper.get(url).content
            #html = requests.get(url).content
            links = re.compile('data-lazy-src="(.+?)"',re.DOTALL).findall(html) # edit for url in tis case openload link
            count = 0
            for link in links:
                if 'youtube' not in link:    # miss trailers
                    if '1080p' in link:
                        qual = '1080p'
                    elif '720p' in link:
                        qual='720p'
                    else:
                        qual='SD'

                    host = link.split('//')[1].replace('www.','')
                    host = host.split('/')[0].split('.')[0].title()
                    count +=1
                    sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})
            return sources
        except Exception as e:
            log_utils.log('[OPENLOADMOVIE-SOURCE] Error: %s' % (e), log_utils.LOGNOTICE)
            return sources

    def resolve(self, url):
        if 'google' in url:
            return directstream.googlepass(url)
        else:
            return url


    def _clean_search(self, title):
            if title == None: return
            title = title.lower()
            title = re.sub('&#(\d+);', '', title)
            title = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
            title = title.replace('&quot;', '\"').replace('&amp;', '&')
            title = re.sub('\\\|/|\(|\)|\[|\]|\{|\}|-|:|;|\*|\?|"|\'|<|>|\_|\.|\?', ' ', title).lower()
            title = ' '.join(title.split())
            return title

    def _clean_title(self, title):
        if title == None: return
        title = str(title)
        title = re.sub('&#(\d);', '', title)
        title = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub('\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\s', '', title)
        return title.lower()
