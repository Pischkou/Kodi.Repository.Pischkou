# -*- coding: utf-8 -*-

#########################################################################
 #  --| NEST ADDON |--
 #########################################################################
 # ----------------------------------------------------------------------
 #  This program is free software: you can redistribute it and/or modify
 #  it under the terms of the GNU General Public License as published by
 #  the Free Software Foundation, either version 3 of the License, or
 #  (at your option) any later version.

 #  This program is distributed in the hope that it will be useful,
 #  but WITHOUT ANY WARRANTY; without even the implied warranty of
 #  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #  GNU General Public License for more details.

 #  You should have received a copy of the GNU General Public License
 #  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 # ----------------------------------------------------------------------
#########################################################################

import os

"""
    Generates the setting lines of sources for video addon
"""

def save_file(data, file):
    try:
        # Write data to the file
        open(file, "w").write(data)
    except Exception, e:
        # Error when writting the file
        print "An error occurred saving %s file!\n%s" % (file, e)

def generate_sources_xml_file(folder, file):
    # Addon list
    sources = os.listdir(folder)
    
    # Inicial addon xml file text
    sources_xml = ""
   	
    # Loop thru and copy each addons addon.xml file
    for source in sources:
        try:
            # Create path of the file
            path = os.path.join(folder, source)

            # Skip folders and .pyo files
            if (os.path.isdir(path) or source.find(".pyo") >= 0 or source.find("__init__.py") >= 0): continue

            source = source.replace(".py","")
            line = '<setting id="provider.$1" type="bool" label="$2" default="true" />'
            line = line.replace("$1", source)
            line = line.replace("$2", source.upper())

            sources_xml += unicode(line + "\n", "UTF-8")
          
        except Exception, e:
            # Missing or poorly formatted addon.xml
            print "Excluding %s for %s" % (path, e)
    
    # Clean and add closing tag
    sources_xml = sources_xml.strip()
    
    # Save file
    save_file(sources_xml.encode("UTF-8"), file)

if (__name__ == "__main__"):
    file_name = "sources.xml"
    sources_dir = "en"
    generate_sources_xml_file(sources_dir, file_name)

    print "Finished Generating Sources XML Lines"