# -*- coding: utf-8 -*-

#########################################################################
 #  --| NEST ADDON |--
 #########################################################################
 # ----------------------------------------------------------------------
 #  This program is free software: you can redistribute it and/or modify
 #  it under the terms of the GNU General Public License as published by
 #  the Free Software Foundation, either version 3 of the License, or
 #  (at your option) any later version.

 #  This program is distributed in the hope that it will be useful,
 #  but WITHOUT ANY WARRANTY; without even the implied warranty of
 #  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #  GNU General Public License for more details.

 #  You should have received a copy of the GNU General Public License
 #  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 # ----------------------------------------------------------------------
#########################################################################

import re, requests, base64, urllib, urlparse, urlresolver

from resources.lib.modules import common
from resources.lib.modules import log_utils

class source:
    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = ['azmovies.ws']
        self.base_link = 'https://azmovies.ws'
        self.search_link = '%s/search.php?q=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            search_id = common.clean_search(title.lower())
            start_url =  self.search_link % (self.base_link, search_id.replace(' ','+'))

            headers = {'User_Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'}
            html = requests.get(start_url,headers=headers,timeout=5).content
            Regex = re.compile('span class="play-btn".+?href="(.+?)".+?class="card-title title">(.+?)</span>',re.DOTALL).findall(html)
            for item_url,name in Regex:
                if not common.clean_title(title).lower() == common.clean_title(name).lower():
                    continue
                
                item_link = self.base_link + "/" + item_url

                html = requests.get(item_link).content
                year_confirm = re.compile('Release:(.+?)<br>',re.DOTALL).findall(html)[0]
                if year in year_confirm:
                    movie_link = item_link

            return movie_link
        except Exception as e:
            log_utils.log('[AZMOVIES-MOVIE] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except Exception as e:
            log_utils.log('[AZMOVIES-TVSHOW] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return
            urldata = urlparse.parse_qs(url)
            urldata = dict((i, urldata[i][0]) for i in urldata)
            title = urldata['tvshowtitle'].replace(':', ' ').lower()

            search_id = common.clean_search(title.lower())
            start_url = self.search_link % (self.base_link,search_id.replace(' ','+'))
            headers = {'User_Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'}
            html = requests.get(start_url,headers=headers,timeout=5).content
            Regex = re.compile('span class="play-btn".+?href="(.+?)".+?class="card-title title">(.+?)</span>',re.DOTALL).findall(html)
            for item_url,name in Regex:

                show_check = '%s - Season%s' % (search_id,season)
                
                if not common.clean_title(show_check).lower() == common.clean_title(name).lower(): continue
                
                tvshow_link = self.base_link + "/" + item_url               
                   
            return tvshow_link
        except Exception as e:
            log_utils.log('[AZMOVIES-EPISODE] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url == None: return
        try:
            #MOVIE
            html = requests.get(url).content
            Regex = re.compile("<ul id='serverul'(.+?)</ul>",re.DOTALL).findall(html)
            links = re.compile('<a href="(.+?)"',re.DOTALL).findall(str(Regex)) 
            count = 0
            for link in links:
                if urlresolver.HostedMediaFile(link):
                    if '1080' in link:
                        qual = '1080p'
                    elif '720' in link:
                        qual='720p'
                    else:
                        qual='SD'
                    host = link.split('//')[1].replace('www.','')
                    host = host.split('/')[0].split('.')[0].title()
                    count +=1
                    sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})

            if len(sources) > 0: return sources
            
            #TV-SHOWS
            headers = {'User_Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'}
            season_page = requests.get(url, headers=headers,timeout=5).content
            episodes = re.compile('target="iframe" href="(.+?)"',re.DOTALL).findall(season_page)
            for link in episodes:
                if urlresolver.HostedMediaFile(link):
                    if '1080' in link:
                        qual = '1080p'
                    elif '720' in link:
                        qual='720p'
                    else:
                        qual='SD'
                    host = link.split('//')[1].replace('www.','')
                    host = host.split('/')[0].split('.')[0].title()
                    sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})

            return sources
        except Exception as e:
            log_utils.log('[AZMOVIES-SOURCE] Error: %s' % (e), log_utils.LOGDEBUG)
            return sources

    def resolve(self, url):
        return url
