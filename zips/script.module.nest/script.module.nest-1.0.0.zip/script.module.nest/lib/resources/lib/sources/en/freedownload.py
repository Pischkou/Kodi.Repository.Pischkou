# -*- coding: utf-8 -*-

#########################################################################
 #  --| NEST ADDON |--
 #########################################################################
 # ----------------------------------------------------------------------
 #  This program is free software: you can redistribute it and/or modify
 #  it under the terms of the GNU General Public License as published by
 #  the Free Software Foundation, either version 3 of the License, or
 #  (at your option) any later version.

 #  This program is distributed in the hope that it will be useful,
 #  but WITHOUT ANY WARRANTY; without even the implied warranty of
 #  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #  GNU General Public License for more details.

 #  You should have received a copy of the GNU General Public License
 #  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 # ----------------------------------------------------------------------
#########################################################################

import re, requests, base64, urllib, urlparse

from resources.lib.modules import common
from resources.lib.modules import log_utils

class source:
    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = ['freemoviedownloads6.com']
        self.base_link = 'http://freemoviedownloads6.com'
        self.search_link = self.base_link + '/index.php'
        self.goog = 'https://www.google.co.uk'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            scrape = common.clean_search(title.lower()).replace(' ','+')

            start_url = '%s/search?q=freemoviedownloads6.com+%s+%s' % (self.goog, scrape,year)

            headers = {'User-Agent':common.random_agent()}

            html = requests.get(start_url,headers=headers,timeout=3).content

            results = re.compile('href="(.+?)"',re.DOTALL).findall(html)
            for url in results:

                if self.base_link in url:

                    if scrape.replace('+','-') in url:
                        if 'webcache' in url:
                            continue

                        confirm_name = common.clean_title(title.lower()) + year 
                        headers={'User-Agent':common.random_agent()}
                        OPEN = requests.get(url,headers=headers,timeout=5).content 
                        getTit = re.compile('<title>(.+?)</title>',re.DOTALL).findall(OPEN)[0]
                        getTit = getTit.split('Free')[0]
                        if common.clean_title(getTit.lower()) == confirm_name:
                            movie_link = url

            return movie_link
        except Exception as e:
            log_utils.log('[FREEDOWNLOAD-MOVIE] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url == None: return
        try:
            headers={'User-Agent':common.random_agent()}
            OPEN = requests.get(url,headers=headers,timeout=5).content
            OPEN = OPEN.split("type='video/mp4'")[1]
            Regex = re.compile('href="(.+?)"',re.DOTALL).findall(OPEN)
            count = 0
            for link in Regex:
                if '1080' in link:
                    res = '1080p'
                elif '720' in link:
                    res = '720p'
                elif '480' in link:
                    res = '480p'
                else:
                    res = 'SD'                
                if '.mkv' in link:
                    count +=1
                    sources.append({'source': 'DirectLink', 'quality': res, 'language': 'en', 'url': link, 'direct': True, 'debridonly': False})
                if '.mp4' in link:
                    count +=1
                    sources.append({'source': 'DirectLink', 'quality': res, 'language': 'en', 'url': link, 'direct': True, 'debridonly': False})

            return sources
        except Exception as e:
            log_utils.log('[FREEDOWNLOAD-SOURCE] Error: %s' % (e), log_utils.LOGDEBUG)
            return sources

    def resolve(self, url):
        return url
