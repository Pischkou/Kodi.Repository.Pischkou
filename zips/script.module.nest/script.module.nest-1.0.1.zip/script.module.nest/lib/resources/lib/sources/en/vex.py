# -*- coding: utf-8 -*-
#########################################################################
 #  --| NEST ADDON |--
 #########################################################################
 # ----------------------------------------------------------------------
 #  This program is free software: you can redistribute it and/or modify
 #  it under the terms of the GNU General Public License as published by
 #  the Free Software Foundation, either version 3 of the License, or
 #  (at your option) any later version.

 #  This program is distributed in the hope that it will be useful,
 #  but WITHOUT ANY WARRANTY; without even the implied warranty of
 #  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #  GNU General Public License for more details.

 #  You should have received a copy of the GNU General Public License
 #  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 # ----------------------------------------------------------------------
#########################################################################

import re, requests, base64, urllib, urlparse, HTMLParser

from resources.lib.modules import common
from resources.lib.modules import log_utils

requests.packages.urllib3.disable_warnings()

class source:
    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = ['vexmovies.org']
        self.base_link = 'http://vexmovies.org'
        self.search_link = '%s/?s=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            search_id = common.clean_search(title.lower())
            start_url = self.search_link % (self.base_link, search_id.replace(' ','+'))
            headers = {'User_Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'}
            html = requests.get(start_url,headers=headers,timeout=5).content
            Regex = re.compile('class="item".+?href="(.+?)".+?alt="(.+?)".+?class="year">(.+?)</span>',re.DOTALL).findall(html)
            for item_url,name,date in Regex:
                if not common.clean_title(title).lower() == common.clean_title(name).lower():
                    continue
                if not year in date:
                    continue
                movie_link = item_url

            return movie_link
        except Exception as e:
            log_utils.log('[VEX-MOVIE] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url == None: return
        try:
            headers = {'User_Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'}
            html = requests.get(url,headers=headers,verify=False,timeout=5).content
            source = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(html)[0]
            if 'consistent.stream' in source:
                headers = {'User_Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'}
                holder = requests.get(source,headers=headers,verify=False,timeout=5).content
                page = re.compile(""":title=["'](.+?)["']\>""").findall(holder)[0]
                clean_up = HTMLParser.HTMLParser()
                decode = clean_up.unescape(page)
                sources_links= re.compile('"sources.+?"(http.+?)"',re.DOTALL).findall(decode)
                count = 0
                for link in sources_links:
                    try:
                        link = link.replace('\\','')
                        
                        if '1080' in link:
                            res='1080p'
                        elif '720' in link:
                            res = '720p'
                        else:
                            res = 'SD'
                        host = link.split('//')[1].replace('www.','')
                        host = host.split('/')[0].split('.')[0].title()
                        count +=1
                        sources.append({'source': host, 'quality': res, 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})
                    except:
                        pass

            return sources
        except Exception as e:
            log_utils.log('[VEX-SOURCE] Error: %s' % (e), log_utils.LOGDEBUG)
            return sources

    def resolve(self, url):
        return url
