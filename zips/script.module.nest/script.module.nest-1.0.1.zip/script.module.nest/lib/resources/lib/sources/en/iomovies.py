# -*- coding: utf-8 -*-
#########################################################################
 #  --| NEST ADDON |--
 #########################################################################
 # ----------------------------------------------------------------------
 #  This program is free software: you can redistribute it and/or modify
 #  it under the terms of the GNU General Public License as published by
 #  the Free Software Foundation, either version 3 of the License, or
 #  (at your option) any later version.

 #  This program is distributed in the hope that it will be useful,
 #  but WITHOUT ANY WARRANTY; without even the implied warranty of
 #  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #  GNU General Public License for more details.

 #  You should have received a copy of the GNU General Public License
 #  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 # ----------------------------------------------------------------------
#########################################################################
import requests, re, urllib3, urlparse, HTMLParser

from resources.lib.modules import client
from resources.lib.modules import directstream
from resources.lib.modules import source_utils
from resources.lib.modules import log_utils
from resources.lib.modules import cfscrape

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['ionlinemovies.com']
        self.base_link = 'https://ionlinemovies.com'
        self.search_link = '%s/?s=%s'
        self.scraper = cfscrape.create_scraper()

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            search_id = self._clean_search(title.lower())
            start_url = self.search_link % (self.base_link,search_id.replace(' ','+'))
            
            headers = {'User_Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'}
            html = self.scraper.get(start_url,headers=headers,timeout=5).content
            
            Regex = re.compile('data-movie-id=.+?href="(.+?)".+?class="mli-info"><h2>(.+?)</h2>.+?rel="tag">(.+?)</a></div>',re.DOTALL).findall(html)
            for item_url,name,date in Regex:
                if not self._clean_title(title).lower() == self._clean_title(name).lower():
                    continue
                if not year in date:
                    continue
                movie_link = item_url
            return movie_link

        except Exception as e:
            log_utils.log('[IONLINEMOVIES-MOVIE] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url == None: return

            headers = {'User_Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'}
            html = self.scraper.get(url).content
            source = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(html)[0]
            if 'consistent.stream' in source:
                headers = {'User_Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'}
                holder = requests.get(source,headers=headers,verify=False,timeout=5).content
                page = re.compile(""":title=["'](.+?)["']\>""").findall(holder)[0]
                clean_up = HTMLParser.HTMLParser()
                decode = clean_up.unescape(page)
                source_links= re.compile('"sources.+?"(http.+?)"',re.DOTALL).findall(decode)
                count = 0
                for link in source_links:
                    if(isinstance(link, dict)): continue
                    link = link.replace('\\','')
                    if '1080' in link:
                        res = '1080p'
                    elif '720' in link:
                        res = '720p'
                    else:
                        res = 'SD'
                    host = link.split('//')[1].replace('www.','')
                    host = host.split('/')[0].split('.')[0].title()
                    count +=1
                    sources.append({'source': host, 'quality': res, 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})
            return sources
        except Exception as e:
            log_utils.log('[IONLINEMOVIES-SOURCES] Error: %s' % (e), log_utils.LOGDEBUG)
            return sources

    def resolve(self, url):
        return url

    def _clean_search(self, title):
        if title == None: return
        title = title.lower()
        title = re.sub('&#(\d+);', '', title)
        title = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub('\\\|/|\(|\)|\[|\]|\{|\}|-|:|;|\*|\?|"|\'|<|>|\_|\.|\?', ' ', title).lower()
        title = ' '.join(title.split())
        return title

    def _clean_title(self, title):
        if title == None: return
        title = str(title)
        title = re.sub('&#(\d);', '', title)
        title = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub('\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\s', '', title)
        return title.lower()
