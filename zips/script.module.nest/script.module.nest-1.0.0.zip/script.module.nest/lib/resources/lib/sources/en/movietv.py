# -*- coding: utf-8 -*-

#########################################################################
 #  --| NEST ADDON |--
 #########################################################################
 # ----------------------------------------------------------------------
 #  This program is free software: you can redistribute it and/or modify
 #  it under the terms of the GNU General Public License as published by
 #  the Free Software Foundation, either version 3 of the License, or
 #  (at your option) any later version.

 #  This program is distributed in the hope that it will be useful,
 #  but WITHOUT ANY WARRANTY; without even the implied warranty of
 #  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #  GNU General Public License for more details.

 #  You should have received a copy of the GNU General Public License
 #  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 # ----------------------------------------------------------------------
#########################################################################

import re, requests, base64, urllib, urlparse

from resources.lib.modules import common
from resources.lib.modules import log_utils

class source:
    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = ['movietv.ws']
        self.base_link = 'http://www.movietv.ws'
        self.search_link = '%s?s=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            search_id = common.clean_search(title.lower())
            start_url = self.search_link % (self.base_link,search_id.replace(' ','+'))
            html = requests.get(start_url,timeout=10).content
            block = re.compile('class="page-category">(.+?)alert-bottom-content"><p',re.DOTALL).findall(html)
            match = re.compile('class="mli-quality">(.+?)</span>.+?<h2>(.+?)</h2>.+?rel="tag">(.+?)</a>.+?class="jtip-bottom">.+?href="(.+?)".+?class="btn\s*btn-block').findall(str(block))
            for qaul,name,yrs,item_url in match:
                item_url = 'http:%s' % (item_url)
                if not year in yrs:
                    continue
                if not common.clean_title(search_id).lower() == common.clean_title(name).lower():
                    continue
                movie_link = item_url

            return movie_link
        except Exception as e:
            log_utils.log('[MOVIETV-MOVIE] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url == None: return
        try:
            OPEN = requests.get(url,timeout=10).content
            block1 = re.compile('id="content-embed"(.+?)id="button-favorite">',re.DOTALL).findall(OPEN)
            Endlinks = re.compile('src="(.+?)"\s*scrolling',re.DOTALL).findall(str(block1))
            count = 0
            for link in Endlinks:
                link = 'http:%s' % (link)
                host = link.split('//')[1].replace('www.','')
                host = host.split('/')[0].lower()
                host = host.split('.')[0]
                count +=1
                if '1080' in link:
                    qual = '1080p'
                elif '720' in link:
                    qual='720p'
                else:
                    qual='SD'
                sources.append({'source': host, 'quality': qual, 'language': 'en', 'url': link, 'direct': True, 'debridonly': False})

            return sources
        except Exception as e:
            log_utils.log('[MOVIETV-SOURCE] Error: %s' % (e), log_utils.LOGDEBUG)
            return sources

    def resolve(self, url):
        return url
