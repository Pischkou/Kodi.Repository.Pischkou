# -*- coding: utf-8 -*-

#########################################################################
 #  --| NEST ADDON |--
 #########################################################################
 # ----------------------------------------------------------------------
 #  This program is free software: you can redistribute it and/or modify
 #  it under the terms of the GNU General Public License as published by
 #  the Free Software Foundation, either version 3 of the License, or
 #  (at your option) any later version.

 #  This program is distributed in the hope that it will be useful,
 #  but WITHOUT ANY WARRANTY; without even the implied warranty of
 #  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #  GNU General Public License for more details.

 #  You should have received a copy of the GNU General Public License
 #  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 # ----------------------------------------------------------------------
#########################################################################

import requests, re, urllib, urlparse

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import directstream
from resources.lib.modules import source_utils
from resources.lib.modules import log_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['1080pMovies.com']
        self.base_link = 'https://1080pmovie.com'
        self.search_link = '/wp-json/wp/v2/posts?search=%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except Exception as e:
            log_utils.log('[1080P-MOVIE] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url == None: return
            urldata = urlparse.parse_qs(url)
            urldata = dict((i, urldata[i][0]) for i in urldata)
            title = urldata['title'].replace(':', ' ').lower()
            year = urldata['year']

            search_id = self._clean_search(title.lower())
            start_url = self.base_link + self.search_link % search_id.replace(' ','%20')
            
            headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36'}
            html = requests.get(start_url,headers=headers,timeout=5).content
            Links = re.compile('"post","link":"(.+?)","title".+?"rendered":"(.+?)"',re.DOTALL).findall(html)
            count = 0
            for link,name in Links:
                link = link.replace('\\','')
                if not self._clean_title(title).lower() == self._clean_title(name).lower(): 
                    continue
                if not year in name:
                    continue
                
                holder = requests.get(link,headers=headers,timeout=5).content
                new = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(holder)[0]
                end = requests.get(new,headers=headers,timeout=5).content
                final_url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(end)[0]
                count +=1
                sources.append({'source': 'Openload','quality': '1080p', 'language': 'en', 'url': final_url, 'direct': False, 'debridonly': False})
            return sources
        except Exception as e:
            log_utils.log('[1080P-SOURCES] Error: %s' % (e), log_utils.LOGDEBUG)
            return sources

    def resolve(self, url):
        return directstream.googlepass(url)

    def _clean_search(self, title):
        if title == None: return
        title = title.lower()
        title = re.sub('&#(\d+);', '', title)
        title = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub('\\\|/|\(|\)|\[|\]|\{|\}|-|:|;|\*|\?|"|\'|<|>|\_|\.|\?', ' ', title).lower()
        title = ' '.join(title.split())
        return title

    def _clean_title(self, title):
        if title == None: return
        title = str(title)
        title = re.sub('&#(\d);', '', title)
        title = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
        title = title.replace('&quot;', '\"').replace('&amp;', '&')
        title = re.sub('\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\s', '', title)
        return title.lower()