# -*- coding: utf-8 -*-
#########################################################################
 #  --| NEST ADDON |--
 #########################################################################
 # ----------------------------------------------------------------------
 #  This program is free software: you can redistribute it and/or modify
 #  it under the terms of the GNU General Public License as published by
 #  the Free Software Foundation, either version 3 of the License, or
 #  (at your option) any later version.

 #  This program is distributed in the hope that it will be useful,
 #  but WITHOUT ANY WARRANTY; without even the implied warranty of
 #  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 #  GNU General Public License for more details.

 #  You should have received a copy of the GNU General Public License
 #  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 # ----------------------------------------------------------------------
#########################################################################

import re, requests, base64, urllib, urlparse

from resources.lib.modules import common
from resources.lib.modules import log_utils

class source:
    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = ['hdpopcorns.com']
        self.base_link = 'http://www.hdpopcorns.com'
        self.search_link = '%s/search/%s'
        self.s = requests.session()

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            search_id = common.clean_search(title.lower())
            start_url = self.search_link % (self.base_link,search_id.replace(' ','+'))
            headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'}
            html = requests.get(start_url,headers=headers,timeout=5).content
           
            links = re.compile('<header>.+?href="(.+?)" title="(.+?)"',re.DOTALL).findall(html)
            for m_url,m_title in links:
                movie_name, movie_year = re.findall("(.*?)(\d+)", m_title)[0]
                if not common.clean_title(title).lower() == common.clean_title(movie_name).lower():
                    continue
                if not year in movie_year:
                    continue
                movie_link = m_url

            return movie_link
        except Exception as e:
            log_utils.log('[HDPOPCORN-MOVIE] Error: %s' % (e), log_utils.LOGDEBUG)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url == None: return
        try:
            headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'}
            OPEN = requests.get(url,headers=headers,timeout=5).content
            headers = {'Origin':'http://hdpopcorns.com', 'Referer':url,
                       'X-Requested-With':'XMLHttpRequest', 'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'}
            count = 0
            try:
                params = re.compile('FileName1080p.+?value="(.+?)".+?FileSize1080p.+?value="(.+?)".+?value="(.+?)"',re.DOTALL).findall(OPEN)
                for param1, param2,param3 in params:
                    request_url = '%s/select-movie-quality.php' %(self.base_link)
                    form_data = {'FileName1080p':param1,'FileSize1080p':param2,'FSID1080p':param3}
                link = requests.post(request_url, data=form_data, headers=headers,timeout=3).content
                final_url = re.compile('<strong>1080p</strong>.+?href="(.+?)"',re.DOTALL).findall(link)[0]
                count +=1
                sources.append({'source': 'DirectLink', 'quality': '1080p', 'language': 'en', 'url': final_url, 'direct': True, 'debridonly': False})
            except:pass
            try:
                params = re.compile('FileName720p.+?value="(.+?)".+?FileSize720p".+?value="(.+?)".+?value="(.+?)"',re.DOTALL).findall(OPEN)
                for param1, param2,param3 in params:
                    request_url = '%s/select-movie-quality.php' %(self.base_link)
                    form_data = {'FileName720p':param1,'FileSize720p':param2,'FSID720p':param3}
                link = requests.post(request_url, data=form_data, headers=headers,timeout=3).content
                final_url = re.compile('<strong>720p</strong>.+?href="(.+?)"',re.DOTALL).findall(link)[0]
                count +=1
                sources.append({'source': 'DirectLink', 'quality': '720p', 'language': 'en', 'url': final_url, 'direct': True, 'debridonly': False})
            except:pass
            return sources
        except Exception as e:
            log_utils.log('[HDPOPCORN-SOURCE] Error: %s' % (e), log_utils.LOGDEBUG)
            return sources

    def resolve(self, url):
        return url
